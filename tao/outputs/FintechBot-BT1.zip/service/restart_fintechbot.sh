#!/bin/zsh
set -euo pipefail
PROJECT="/Users/nguyenchitinh/Documents/Codex/2026-09-10/tao/outputs/FintechBot"
mkdir -p "$PROJECT/logs"
pkill -f "$PROJECT/run.py" || true
nohup "$PROJECT/.venv/bin/python" "$PROJECT/run.py" >> "$PROJECT/logs/fintechbot.out.log" 2>> "$PROJECT/logs/fintechbot.error.log" < /dev/null &
echo "Fintech Bot started at http://127.0.0.1:8010"
