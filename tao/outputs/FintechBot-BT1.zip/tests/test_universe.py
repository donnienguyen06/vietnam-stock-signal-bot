import asyncio
import httpx
from fintech.provider import CafeF


def test_universe_parses_current_cafef_options(tmp_path, monkeypatch):
    from fintech import storage
    monkeypatch.setattr(storage, 'DATA', tmp_path); storage.init()
    symbols=''.join(f'<option value="S{i:03d}">S{i:03d}</option>' for i in range(120))
    async def scenario():
        provider=CafeF()
        async def get(url,*args,**kwargs):return httpx.Response(200,request=httpx.Request('GET',url),text='<html>'+symbols+'</html>')
        provider.client.get=get
        try:
            result=await provider.universe();assert len(result)==120;assert result[0]=='S000';assert storage.get('market_universe')==result
        finally:await provider.close()
    asyncio.run(scenario())


def test_universe_uses_cached_list_when_source_is_unavailable(tmp_path, monkeypatch):
    from fintech import storage
    monkeypatch.setattr(storage, 'DATA', tmp_path); storage.init()
    cached=[f'S{i:03d}' for i in range(100)];storage.put('market_universe',cached)
    async def scenario():
        provider=CafeF()
        async def fail(*args,**kwargs):raise httpx.ConnectError('offline')
        provider.client.get=fail
        try:assert await provider.universe()==cached
        finally:await provider.close()
    asyncio.run(scenario())
