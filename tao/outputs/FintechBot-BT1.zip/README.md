# Fintech Bot — tín hiệu đầu tư cổ phiếu Việt Nam (BT1)

Sản phẩm gồm một FastAPI local dashboard và Telegram long-polling bot. Dữ liệu giao dịch và chỉ số cơ bản lấy từ các endpoint công khai của CafeF; hệ thống có cache SQLite, kiểm tra schema, retry/backoff và thông báo lỗi rõ ràng.

## Chạy demo

**Muốn chạy khi Mac tắt:** sử dụng bản Docker Compose trên VPS theo [CHAY_24_7.md](docs/CHAY_24_7.md). Bản này có HTTPS, mật khẩu quản trị, volume bền vững và tự khởi động lại. Cần máy chủ thật để kích hoạt; source local không tự tạo hosting.

```bash
cd /Users/nguyenchitinh/Documents/Codex/2026-09-10/tao/outputs/FintechBot
source .venv/bin/activate
python run.py
```

Mở http://127.0.0.1:8010. Lần chạy đầu sẽ tải danh sách mã hiện hành từ CafeF, cần khoảng 1–3 phút tùy nguồn CafeF. Bot quét lại mỗi 15 phút.

## Kết nối Telegram

Mở mục **Kết nối Telegram**, tạo bot bằng `@BotFather` → `/newbot`, nhập token vào biểu mẫu. Mở bot, gửi `/start`, sau đó `/subscribe`. Token chỉ lưu tại `data/telegram.json` với quyền file riêng tư và không nằm trong source code. Bot chạy long polling, chỉ nhận chat riêng, chống gửi trùng theo mã/phiên/hướng.

Các lệnh: `/signals`, `/stock MÃ_CỔ_PHIẾU`, `/fund MÃ_CỔ_PHIẾU`, `/backtest MÃ_CỔ_PHIẾU`, `/chart MÃ_CỔ_PHIẾU`, `/subscribe`, `/unsubscribe`, `/status`, `/help`, `/share`.

## Mời mọi người sử dụng

Sau khi kết nối token, chia sẻ link `https://t.me/<username_bot>`. Mọi người chỉ cần mở link, bấm Start rồi `/subscribe`; không cần token hoặc Chat ID. Mỗi người có trạng thái đăng ký riêng. `/share` trả link mời; menu nhanh cung cấp các lệnh chính. Chủ bot giữ dashboard trên localhost. Bot chỉ trả lời khi máy chạy dịch vụ còn hoạt động và có mạng; muốn liên tục 24/7 cần máy chủ luôn bật.

## Kiến trúc

`CafeF danh sách mã + OHLCV/BCTC → provider.py (chuẩn hóa, cache, retry) → strategy.py (EMA/RSI/RVOL, value filter) → engine.py (quét toàn thị trường, tối đa 6 yêu cầu đồng thời) → app.py (REST/UI) và bot.py (Telegram)`.

Ứng dụng bind `127.0.0.1`, không có public hosting, không nhận lệnh giao dịch. SQLite dùng WAL. Dữ liệu giá điều chỉnh được quy đổi VND theo tỷ lệ `GiaDieuChinh/GiaDongCua`; quyết định dùng phiên đã đóng.

## Lệnh ảnh biểu đồ

`/chart MÃ_CỔ_PHIẾU` gửi ảnh PNG của mã người dùng nhập. Ảnh gồm 80 phiên đóng cửa điều chỉnh, EMA20/EMA50, khối lượng và ô giá gần nhất được yêu cầu mới từ CafeF mỗi lần gọi. Giá gần nhất chưa điều chỉnh được hiển thị riêng để không trộn với lịch sử điều chỉnh. Cả ảnh và caption ghi thời điểm nguồn, thời điểm lấy ảnh, cảnh báo cache/độ trễ nếu có.

Đây là ảnh chụp theo yêu cầu của chart ngày kèm giá mới nhất, không phải chuỗi nến realtime trong phiên và không tự cập nhật sau khi gửi. Nếu CafeF không trả quote hợp lệ, bot vẫn gửi chart lịch sử và ghi rõ chưa lấy được giá mới nhất. Dùng lại lệnh để lấy ảnh mới.

Có thể thử tại tab Kết nối Telegram trên dashboard, chưa cần gửi tin thật. Sau cập nhật cần cài lại `requirements.txt` rồi khởi động lại dịch vụ; bản VPS chạy `docker compose up -d --build`. Menu lệnh được đồng bộ khi bot khởi động.

Gửi ảnh dùng Telegram [sendPhoto](https://core.telegram.org/bots/api#sendphoto).

## Giả định backtest

`/backtest MÃ_CỔ_PHIẾU` dùng vốn 100 triệu, lô 100, mua ở open phiên sau, phí 0,15% mỗi chiều, thuế bán 0,1%, trượt giá 0,1%, khóa bán 3 phiên. Có warm-up 60 phiên, chỉ mô phỏng long-only và định giá vị thế cuối kỳ theo close. Kết quả là mô phỏng giáo dục, không phải cam kết lợi nhuận.

## Kiểm thử

```bash
cd /Users/nguyenchitinh/Documents/Codex/2026-09-10/tao/outputs/FintechBot
.venv/bin/python -m pytest -q
```

38 bài kiểm tra bao phủ chỉ báo nhân quả, RSI, backtest, cache, chống gửi trùng, xác thực mã, đăng nhập quản trị, chặn sai nguồn, định dạng ảnh PNG, giá được lấy mới mỗi lần gọi và upload ảnh Telegram bằng API giả lập. Đã kiểm tra ảnh với dữ liệu CafeF thật; chưa kiểm thử gửi ảnh tới tài khoản Telegram thật.

## Hạn chế dữ liệu

CafeF có thể chặn hoặc đổi cấu trúc. Bot không bypass CAPTCHA/IP block và không tắt kiểm tra TLS; nó retry rồi dùng bản cache gần nhất, đánh dấu `cached/stale`, đồng thời không phát alert mới từ dữ liệu cũ. Khi nộp bài, có thể chụp màn hình dashboard và phần backtest làm minh chứng demo.
