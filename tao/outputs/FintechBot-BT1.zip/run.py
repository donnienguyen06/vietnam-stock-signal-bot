#!/usr/bin/env python3
import os
from pathlib import Path
import uvicorn
if __name__=='__main__':
    os.chdir(Path(__file__).resolve().parent)
    from fintech.access import settings
    public, _, _ = settings()
    uvicorn.run('fintech.app:app',host='0.0.0.0' if public else '127.0.0.1',
                port=8010,workers=1,log_level='warning')
