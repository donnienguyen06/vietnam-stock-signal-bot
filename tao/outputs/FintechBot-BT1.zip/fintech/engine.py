import asyncio
from datetime import datetime
from .provider import CafeF, SYMBOLS, now, validate_symbol
from .strategy import signal, backtest
from . import storage

class Engine:
    def __init__(self):
        self.provider=CafeF();self.signals={};self.errors={};self.last_scan=None;self.scanning=False
        self.watchlist=storage.get('watchlist',storage.get('market_universe',list(SYMBOLS)));self.market_universe=[]
        self.scan_total=0;self.scan_done=0;self.universe_complete=False;self.lock=asyncio.Lock();self.symbol_locks={};self.bot=None
    async def analyze(self,symbol,force=False):
        symbol=validate_symbol(symbol)
        async with self.symbol_locks.setdefault(symbol,asyncio.Lock()):
            data=await self.provider.load(symbol,force)
        s=signal(data['bars'],data['fundamentals']);age=(now().date()-datetime.fromisoformat(s['date']).date()).days
        s.update(symbol=symbol,name=SYMBOLS.get(symbol,symbol),fundamentals=data['fundamentals'],quote=data['quote'],
            fetched_at=data['fetched_at'],source=data['source'],cached=data['cached'],error=data['error'],stale=age>4)
        if symbol in self.watchlist:self.signals[symbol]=s
        return s
    async def scan(self):
        if self.scanning:return
        self.scanning=True
        try:
            self.market_universe=await self.provider.universe()
            self.universe_complete=len(self.market_universe)>=100
            # A discovered CafeF universe is authoritative. A short fallback remains visible as degraded mode.
            if len(self.market_universe)>=100:
                self.watchlist=self.market_universe;storage.put('watchlist',self.watchlist)
            symbols=list(self.watchlist);self.scan_total=len(symbols);self.scan_done=0
            semaphore=asyncio.Semaphore(6)
            async def one(symbol):
                async with semaphore:
                    try:await self.analyze(symbol,True);self.errors.pop(symbol,None)
                    except Exception as e:self.errors[symbol]=str(e) if isinstance(e,ValueError) else 'Không xử lý được dữ liệu mã này.'
                    finally:self.scan_done+=1
            await asyncio.gather(*(one(symbol) for symbol in symbols))
            '''
            for symbol in symbols:
                try:await self.analyze(symbol,True);self.errors.pop(symbol,None)
                except Exception as e:self.errors[symbol]=str(e) if isinstance(e,ValueError) else 'Không xử lý được dữ liệu mã này.'
                await asyncio.sleep(.3)
            '''
            self.last_scan=now().isoformat()
            if self.bot:await self.bot.alerts(list(self.signals.values()))
        finally:self.scanning=False
    async def loop(self):
        while True:
            await self.scan();await asyncio.sleep(900)
    async def test(self,symbol,months=6):
        data=await self.provider.load(validate_symbol(symbol))
        b=backtest(data['bars'],months);b.update(symbol=symbol,source=data['source'],fetched_at=data['fetched_at'],cached=data['cached'])
        return b
