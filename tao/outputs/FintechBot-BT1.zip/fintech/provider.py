"""CafeF public website adapter. Schema checks, retry, timestamped local cache.
No credentials, CAPTCHA bypass, proxies, or TLS disabling.
"""
import asyncio
import math
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import httpx
from html import unescape
from . import storage

TZ = ZoneInfo('Asia/Ho_Chi_Minh')
BASE = 'https://cafef.vn/du-lieu/Ajax/PageNew/'
SYMBOLS = {'FPT':'FPT','HPG':'Hòa Phát','VCB':'Vietcombank','SSI':'Chứng khoán SSI','MWG':'Thế Giới Di Động','MBB':'MB Bank','VNM':'Vinamilk','TCB':'Techcombank','VIC':'Vingroup','VHM':'Vinhomes'}

def now(): return datetime.now(TZ)
def validate_symbol(value):
    s=value.strip().upper()
    if not re.fullmatch('[A-Z][A-Z0-9]{2,5}',s): raise ValueError('Mã cổ phiếu phải có 3–6 chữ/số. Hãy nhập mã bạn muốn xem.')
    return s

def number(x):
    try:
        n=float(str(x).replace(',','').replace('%',''))
        return n if math.isfinite(n) else None
    except (TypeError,ValueError):return None

class CafeF:
    def __init__(self):
        self.client=httpx.AsyncClient(timeout=20,follow_redirects=True,headers={'User-Agent':'FintechBot-BT1/1.0 (educational)','Referer':'https://cafef.vn/du-lieu/'})
    async def close(self):await self.client.aclose()
    async def universe(self):
        """Discover the current CafeF equity list instead of treating a sample as the market."""
        try:
            r=await self.client.get('https://cafef.vn/du-lieu/lich-su-giao-dich-fpt-1.chn')
            r.raise_for_status()
            values=re.findall(r'<option[^>]+value=["\']([A-Z][A-Z0-9]{2,5})["\'][^>]*>',unescape(r.text),re.I)
            values=[x.upper() for x in values if x.upper() not in {'ALL','VNINDEX'}]
            values=list(dict.fromkeys(values))
            if len(values)>=100:
                storage.put('market_universe',values)
                return values
        except (httpx.HTTPError,ValueError):
            pass
        cached=storage.get('market_universe')
        if cached and len(cached)>=100:return cached
        # Safe fallback is intentionally explicit: it is not presented as a complete market scan.
        return list(SYMBOLS)
    async def request(self,path,params):
        for attempt in range(3):
            try:
                r=await self.client.get(BASE+path,params=params)
                r.raise_for_status(); j=r.json()
                if j.get('Data') is None:raise ValueError('CafeF không trả dữ liệu phù hợp')
                return j['Data']
            except (httpx.HTTPError,ValueError) as e:
                if isinstance(e,httpx.HTTPStatusError) and e.response.status_code in (401,403):raise ValueError('CafeF từ chối truy cập; dùng cache, thử lại sau.') from None
                if attempt==2:raise ValueError('Nguồn CafeF không khả dụng hoặc đổi cấu trúc.') from None
                await asyncio.sleep(2**attempt)
    async def history(self,symbol):
        symbol=validate_symbol(symbol); today=now(); rows=[]; seen=set()
        for window in range(5):
            window_end=today-timedelta(days=window*89)
            window_start=window_end-timedelta(days=88)
            for page in range(1,6):
                data=await self.request('DataHistory/PriceHistory.ashx',dict(ExchangeType='hose',Symbol=symbol,StartDate=window_start.strftime('%m/%d/%Y'),EndDate=window_end.strftime('%m/%d/%Y'),PageIndex=page,PageSize=20))
                batch=data.get('Data') or []
                if not batch:break
                fresh=0
                for r in batch:
                    dt=datetime.strptime(r['Ngay'],'%d/%m/%Y').date()
                    if dt>today.date() or (dt==today.date() and today.hour<16):continue
                    if dt.isoformat() in seen:continue
                    raw=number(r.get('GiaDongCua'));adj=number(r.get('GiaDieuChinh'))
                    vals=[number(r.get(k)) for k in ['GiaMoCua','GiaCaoNhat','GiaThapNhat','KhoiLuongKhopLenh']]
                    if not raw or not adj or any(v is None for v in vals):raise ValueError('OHLCV thiếu hoặc sai kiểu.')
                    o,h,l,v=vals
                    if min(o,h,l,raw)<=0 or v<0 or h<max(o,l,raw) or l>min(o,h,raw):raise ValueError('OHLCV không hợp lệ.')
                    ratio=adj/raw
                    rows.append(dict(date=dt.isoformat(),open=o*ratio*1000,high=h*ratio*1000,low=l*ratio*1000,close=adj*1000,volume=int(v),raw_close=raw*1000))
                    seen.add(dt.isoformat());fresh+=1
                if not fresh:break
                if len(rows)>=300 or page*20>=data.get('TotalCount',100000):break
                await asyncio.sleep(.25)
            if len(rows)>=260:break
        rows.sort(key=lambda x:x['date'])
        if len(rows)<60:raise ValueError(f'CafeF chỉ trả {len(rows)} phiên; cần ít nhất 60.')
        return rows
    async def quote(self,symbol):
        d=await self.request('PriceRealTimeHeader.ashx',{'Symbol':symbol})
        m=re.search(r'\d{10,}',str(d.get('ThoiGian','')))
        return dict(price=(number(d.get('Gia')) or 0)*1000,reference=(number(d.get('GiaThamChieu')) or 0)*1000,volume=number(d.get('KhoiLuong')),timestamp=datetime.fromtimestamp(int(m[0])/1000,TZ).isoformat() if m else None,source='CafeF • giá gần nhất, có thể trễ')
    async def fundamentals(self,symbol):
        basic=await self.request('ChiSoTaiChinh.ashx',{'Symbol':symbol})
        out=dict(source='CafeF',fetched_at=now().isoformat(),roe=None,revenue_growth=None,profit_growth=None,debt_equity=None,period=None,errors=[])
        for r in basic:
            text=re.sub('<[^>]+>','',str(r.get('Text',''))).strip();val=number(r.get('Value'))
            if text.startswith('EPS cơ bản'):out['eps']=val*1000 if val is not None else None
            if text=='P/E':out['pe']=val
            if text=='P/B':out['pb']=val
            if r.get('Code')=='ThoiGian':out['eps_period']=r.get('Value')
        yr=now().year
        try:
            ratio=await self.request('GetDataChiSoTaiChinh.ashx',dict(Symbol=symbol,TotalRow=8,EndDate=yr,ReportType='NAM',Sort='DESC'))
            rr=sorted(ratio['Value'],key=lambda x:(x['Year'],x.get('Quater',0)),reverse=True)
            if rr:
                out['roe']=next((number(v['Value']) for v in rr[0]['Value'] if v['Code']=='ROE'),None);out['roe_period']=rr[0]['Time']
            income=await self.request('FinanceReport.ashx',dict(Type=1,Symbol=symbol,TotalRow=8,EndDate=f'4-{yr}',ReportType='QUY',Sort='DESC'))
            reports=sorted(income['Value'],key=lambda x:(x['Year'],x.get('Quater',0)),reverse=True)
            if reports:
                latest=reports[0];out['period']=latest['Time'];out['income_reports']=reports
                prior=next((x for x in reports if x['Year']==latest['Year']-1 and x['Quater']==latest['Quater']),None)
                if prior:
                    a={v['Code']:number(v['Value']) for v in latest['Value']};b={v['Code']:number(v['Value']) for v in prior['Value']}
                    for key,code in [('revenue_growth','DTTBHCCDV'),('profit_growth','NetIncome')]:
                        if a.get(code) is not None and b.get(code) is not None and b[code]>0:out[key]=round((a[code]/b[code]-1)*100,2)
            balance=await self.request('FinanceReport.ashx',dict(Type=2,Symbol=symbol,TotalRow=4,EndDate=f'4-{yr}',ReportType='QUY',Sort='DESC'))
            if balance['Value']:
                r=balance['Value'][0];v={x['Code']:number(x['Value']) for x in r['Value']}
                if v.get('TotalOwnerCapital',0) and v.get('TotalDebt') is not None:out['debt_equity']=round(v['TotalDebt']/v['TotalOwnerCapital'],3);out['debt_period']=r['Time']
        except (ValueError,KeyError,TypeError):out['errors'].append('Một phần báo cáo thiếu hoặc thay đổi cấu trúc; không suy đoán giá trị.')
        return out
    async def load(self,symbol,force=False):
        cached=storage.get('market:'+symbol)
        if cached and not force and (now()-datetime.fromisoformat(cached['fetched_at'])).total_seconds()<900:return cached
        try:
            bars=await self.history(symbol)
            try:fund=await self.fundamentals(symbol)
            except ValueError:fund={'errors':['Chưa lấy được BCTC'],'source':'CafeF'}
            try:quote=await self.quote(symbol)
            except ValueError:quote=None
            result=dict(symbol=symbol,bars=bars,fundamentals=fund,quote=quote,fetched_at=now().isoformat(),source='CafeF',cached=False,error=None)
            storage.put('market:'+symbol,result);return result
        except (ValueError,KeyError,TypeError) as e:
            if cached:return dict(cached,cached=True,error=str(e))
            raise ValueError(str(e)) from None
